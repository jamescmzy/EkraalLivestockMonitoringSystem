package com.kamwana.e_kraal;

import static android.content.ContentValues.TAG;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.Switch;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class Home extends AppCompatActivity {

    View morelayout;
    ImageView more;
    RelativeLayout cancel;

    LinearLayout profile, settings, help, about, logOut;
    ImageView back;
    TextView tempValue, humidityValue, airValue;

    Switch bulb, fan;
    boolean b=false;
    boolean f=false;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.home);

        //for turning the on and of the fan and the bulb

        bulb=findViewById(R.id.switchButton);
        fan=findViewById(R.id.switchButton2);

        //the code for a side layout
        morelayout=findViewById(R.id.more_layout);
        more=findViewById(R.id.more);
        cancel=morelayout.findViewById(R.id.cancel);

        //the views for setting the values on textView
        tempValue=findViewById(R.id.temp_value);
        humidityValue=findViewById(R.id.humidity_value);
        airValue=findViewById(R.id.air_value);

        profile=morelayout.findViewById(R.id.profile);
        settings=morelayout.findViewById(R.id.settings);
        help=morelayout.findViewById(R.id.help);
        about=morelayout.findViewById(R.id.about);
        logOut=morelayout.findViewById(R.id.log_out);

        back=morelayout.findViewById(R.id.back);



        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                morelayout.setVisibility(View.GONE);
            }
        });
        profile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(getApplicationContext(), PersonalProfile.class));
            }
        });

        settings.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                startActivity(new Intent(getApplicationContext(), Settings.class));
            }
        });

        help.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

            }
        });

        about.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

            }
        });

        logOut.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(getApplicationContext(), Registration.class));
            }
        });

        cancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                morelayout.setVisibility(View.GONE);
            }
        });
        more.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                morelayout.setVisibility(View.VISIBLE);
            }
        });


        Firebase();
    }

    public void Firebase(){
        //this is the code for firebase
        FirebaseDatabase database = FirebaseDatabase.getInstance();
        DatabaseReference myRef = database.getReference("temperature");
        DatabaseReference myRef2= database.getReference("humidity");
        DatabaseReference myRef3= database.getReference("air");
        DatabaseReference bf= database.getReference("bulb");
        DatabaseReference bb= database.getReference("fan");



        bulb.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(b){
                    bb.setValue("off");
                    b=false;
                }else {

                    bb.setValue("on");
                    b=true;
                }
            }
        });

        fan.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(f){
                    bf.setValue("off");
                    f=false;
                }else {

                    bf.setValue("on");
                    f=true;
                }
            }
        });
        // Read from the database
        myRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                // This method is called once with the initial value and again
                // whenever data at this location is updated.
                String value = dataSnapshot.getValue(String.class);

                tempValue.setText(value);
            }

            @Override
            public void onCancelled(DatabaseError error) {
                // Failed to read value
                Log.w(TAG, "Failed to read value.", error.toException());
            }
        });

        myRef2.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                String value = snapshot.getValue(String.class);


            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });

        myRef3.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                String value = snapshot.getValue(String.class);

                airValue.setText(value);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });

    }
    @Override
    public void onBackPressed() {
        super.onBackPressed();
        morelayout.setVisibility(View.GONE);
    }
}
